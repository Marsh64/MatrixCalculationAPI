package M

import M.matrix.Types
import M.matrix.dto.MatrixImplListDto
import kotlinx.serialization.json.Json
import kotlinx.serialization.encodeToString
import kotlinx.serialization.*
import kotlinx.serialization.descriptors.*
import kotlinx.serialization.encoding.*

import java.util.Date

object DateAsLongSerializer : KSerializer<Date> {
    override val descriptor: SerialDescriptor = PrimitiveSerialDescriptor("Date", PrimitiveKind.LONG)
    override fun serialize(encoder: Encoder, value: Date) = encoder.encodeLong(value.time)
    override fun deserialize(decoder: Decoder): Date = Date(decoder.decodeLong())
}

/*
@Serializable
data class ProgrammingLanguage(
    val name: String,
    @Serializable(with = DateAsLongSerializer::class)
    val stableReleaseDate: Date
)

fun main() {
    val data = ProgrammingLanguage("Kotlin", SimpleDateFormat("yyyy-MM-ddX").parse("2016-02-15+00"))
    println(data)
    val a = Json.encodeToString(data)
    println(a)
    val b = Json.decodeFromString<ProgrammingLanguage>(a)
    println(b)

}
*/

/*
@Serializable
data class User(val name: String, val yearOfBirth: Int)


fun main() {
// Faster encoding...
    val data = User("Louis", 1901)
    val string = Json.encodeToString(data)
    println(string) // {"name":"Louis","yearOfBirth":1901}

// ...and faster decoding!
    val obj = Json.decodeFromString<Int>(string)
    println(obj) // User(name=Louis, yearOfBirth=1901)
}
*/

fun main(){
//    println("Hello World!")
//    val s = Json.encodeToString(Test, Test(10))
//    println(s) // 5
//
//    val outS = Json.decodeFromString(Test, s)
//    println(outS) // It



    val array = mutableListOf<MutableList<Int>>(mutableListOf<Int>(1, 2), mutableListOf<Int>(3, 4))
    val mdto = MatrixImplListDto<Int>(2, 2, Types.int, array)
    val a = Json.encodeToString(mdto)
    println(a)
    val b = Json.encodeToString(mdto)
    println(b)

    val array2 = mutableListOf<MutableList<Float>>(mutableListOf<Float>(1.2f, 2.5f), mutableListOf<Float>(3.4f, 4.9f))
    val mdto2 = MatrixImplListDto<Float>(2, 2, Types.float, array2)
    val a2 = Json.encodeToString(mdto2)
    println(a2)
    val b2 = Json.encodeToString(mdto2)
    println(b2)
//    //val b = Json.decodeFromString<MatrixImplListDto<Int>>(a)
//    println(mdto)
//    println(a)
//    //println(b)

}

/*
@Serializable
data class example(
    val a: Int,
    val b: Float
)

@Serializable()
data class MatrixImplListDto<E>(
    val rows: Int,
    val columns: Int,
    @Serializable(with = TypesSerializer::class)
    val type: Types,
    val matrix: MutableList<MutableList<E>>
)


object TypesSerializer : KSerializer<Types> {
    fun fromValue(value: Int) = Types.values().find { it.num == value }!!
    override val descriptor = PrimitiveSerialDescriptor("Types", PrimitiveKind.INT)
    override fun deserialize(decoder: Decoder) = fromValue(decoder.decodeInt())
    override fun serialize(encoder: Encoder, value: Types) = encoder.encodeInt(value.num)
}

@Serializable(with=Test.Companion::class)
enum class Test(val value: Int) {
    It(5);

    companion object : KSerializer<Test> {
        fun fromValue(value: Int) = values().find { it.value == value }!!
        override val descriptor = PrimitiveSerialDescriptor("Test", PrimitiveKind.INT)
        override fun deserialize(decoder: Decoder) = fromValue(decoder.decodeInt())
        override fun serialize(encoder: Encoder, value: Test) = encoder.encodeInt(value.value)
    }
}

//
//class Expression private constructor(){
//
//    internal var operation: Operation = Operation.None
//    internal var rightExpr: Expression? = null
//    internal var leftExpr: Expression? = null
//    internal var rightMatrix: Expression? = null
//    internal var leftMatrix: Expression? = null
//    internal var opType: OperationType? = null
//    internal var elType: ElementType? = null
//
//    //fun compute() : Future<MAtrixDto> = TaskManager.compute(this)
//
//    // the only public constructor
//    constructor(init: Expression.() -> Expression) : this() {
//        val expr = init()
//        this.operation = expr.operation
//        this.leftExpr = expr.leftExpr
//        this.rightExpr = expr.rightExpr
//        this.leftMatrix = expr.leftMatrix
//        this.rightMatrix = expr.rightMatrix
//        this.opType = expr.opType
//        this.elType = expr.elType
//    }
//
//    private constructor(operation: Operation, leftExpr: Expression, rightExpr: Expression) : this() {
//        this.operation = operation
//        this.leftExpr = leftExpr
//        this.rightExpr = rightExpr
//    }
//
//    private constructor(operation: Operation, leftMatrix: MatrixDto, rightMatrix: MatrixDto) : this() {
//        this.operation = operation
//        this.leftMatrix = leftMatrix
//        this.rightMatrix = rightMatrix
//    }
//
//    private constructor(operation: Operation, leftExpr: Expression, rightMatrix: MatrixDto) : this() {
//        this.operation = operation
//        this.leftExpr = leftExpr
//        this.rightMatrix = rightMatrix
//    }
//
//    private constructor(operation: Operation, leftMatrix: MatrixDto, rightExpr: Expression) : this() {
//        this.operation = operation
//        this.leftMatrix = leftMatrix
//        this.rightExpr = rightExpr
//    }
//
//    /*
//    table operation table
//    expression operation table
//    table operation expression
//    expression operation expression
//     */
//
//
//    //TODO перегрузить нормальный плюс
//    infix fun MatrixDto.opPlus(matrix: MatrixDto) = Expression(Operation.Plus, this@opPlus, table)
//    infix fun opPlus(matrix: MatrixDto) = Expression(Operation.Plus, this, matrix)
//    infix fun MatrixDto.opPlus(expr: Expression) = Expression(Operation.Plus, this@opPlus, expr)
//    infix fun opPlus(expr: Expression) = Expression(Operation.INTERSECT, this, expr)
//    //-, *, inverse, transpose ....
//
//
*/