package M.dsl

//DSL, строящий и вычислщий пример как дерево
/*
Пример использования:

    val exp = Expression {
        Value {
            "a" eq 5
            "b" eq 6
            "c" eq 7
        }
        Instance {
            5 subPlus 6
            5 subMinus 4
            SumInstance {
                8 subMul 10
                5 subMinus 2
            }
            DivInstance {
                0 subPlus 1
                5 subPlus 2
                1 subMinus 1
                DivInstance {
                    8 subMul 9
                    54 subMinus 2
                    SumInstance {
                        0 subPlus 1
                        5 subPlus 2
                        1 subMinus 1
                    }
                }
                5 subPlus 2
                1 subMinus 1
                SumInstance {
                    0 subPlus 1
                    5 subPlus 2
                    1 subMinus 1
                }
            }
        }
    }.build()

    println(exp)
 */

fun Expression(initializer: ExpressionBuilder.() -> Unit): ExpressionBuilder {
    return ExpressionBuilder().apply(initializer)
}

class ValueBuilder{
    private val accordance = mutableMapOf<String, Int>()

    infix fun String.eq(temp: Int){
        accordance.put(this, temp)
    }

    fun getValue() = accordance
}

abstract class InstanceBuilder{
    open var result: Int = 0

    open fun SumInstance(initializer: InstanceBuilder.() -> Unit) {}

    open fun DivInstance(initializer: InstanceBuilder.() -> Unit) {}

    open infix fun Int.subPlus(temp: Int) {}

    open infix fun Int.subMinus(temp: Int){}

    open infix fun Int.subMul(temp: Int){
        result += this * temp
    }

    fun getRes() = result

}


class ExpressionBuilder {
    //private var variables = mutableListOf<String>()
    var accordance = mutableMapOf<String, Int>() //сделать private
    private var result: Int = 0//сделать с lateinit

    fun Value(initializer: ValueBuilder.() -> Unit) {
        accordance = ValueBuilder().apply(initializer).getValue()
    }

    fun Instance(initializer: InstanceBuilder.() -> Unit) {
        result = SumInstanceBuilder().apply(initializer).getRes()
    }

    fun build(): String{
        return result.toString()
    }
}

class SumInstanceBuilder : InstanceBuilder(){
    override var result: Int = 0

    override fun SumInstance(initializer: InstanceBuilder.() -> Unit) {
        result += SumInstanceBuilder().apply(initializer).getRes()
    }

    override fun DivInstance(initializer: InstanceBuilder.() -> Unit) {
        result -= DivInstanceBuilder().apply(initializer).getRes()
    }

    override infix fun Int.subPlus(temp: Int){
        result += this + temp
    }

    override infix fun Int.subMinus(temp: Int){
        result += this - temp
    }

    override infix fun Int.subMul(temp: Int){
        result += this * temp
    }
}

class DivInstanceBuilder : InstanceBuilder(){
    override var result: Int = 0

    override fun SumInstance(initializer: InstanceBuilder.() -> Unit) {
        result += SumInstanceBuilder().apply(initializer).getRes()
    }

    override fun DivInstance(initializer: InstanceBuilder.() -> Unit) {
        result -= DivInstanceBuilder().apply(initializer).getRes()
    }

    override infix fun Int.subPlus(temp: Int){
        result -= this + temp
    }

    override infix fun Int.subMinus(temp: Int){
        result -= this - temp
    }

    override infix fun Int.subMul(temp: Int){
        result -= this * temp
    }
}