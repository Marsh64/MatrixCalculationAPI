package M.dsl

import java.util.Arrays


object BasicCombinationScheme {

    //apply function: T1×(T1->T2)->T2
    fun <T1, T2> action(a: T1, fun1: (T1) -> T2): T2 = fun1(a)

    //if() then else: Bool×T×T->T
    fun <T> condition (bool : Boolean, temp1: T, temp2: T): T{
        return if (bool) temp1 else temp2
    }

    //composition: T2->T3→(T1->T2)→(T1->T3)
    fun <T1, T2, T3> composition (fun1: (T1) -> T2, fun2: (T2) -> T3): (T1) -> T3{
        return {temp: T1 -> fun2(fun1(temp))}
    }

    //Собираем элементы в набор элементов: T1->...->Tn->[T1, ..., Tn]
    fun <T> merge(vararg temps: T): ArrayList<T> = arrayListOf<T>(*temps)

    //map: (T1->T2)->[T1]->[T2]
    fun <T1, T2> map(temp: ArrayList<T1>, fun1: (T1) -> T2): ArrayList<T2>{
        val arr = ArrayList<T2>()
        for (i in temp){
            arr.add(fun1(i))
        }

        return arr
    }

    //flatMap: (T1->[T2])->[T1]->[T2]
    fun <T1, T2> flatMap(temp: ArrayList<T1>, fun1: (T1) -> ArrayList<T2>): ArrayList<T2>{
        val arr = ArrayList<T2>()
        for (i in temp){
            arr+=fun1(i)
        }

        return arr
    }

    //reduce: [T]->(T×T->T)->T (упрощенный, только с одним типом)
    fun <T> reduce(temp: ArrayList<T>, fun1: (accumulator: T, value: T) -> T): T{
        if (temp.size < 2) throw IllegalArgumentException("reduce can't be applied to small array")

        var res =  fun1(temp[0], temp[1])
        for (i in 2 until temp.size){
            res = fun1(res, temp[i])
        }

        return res
    }

    //fold: [T1]->T2->(T2×T1->T2)->T2
    fun <T1, T2> fold(temp: ArrayList<T1>, initial: T2, fun1: (accumulator: T2, value: T1) -> T2): T2{
        var res = initial
        for (i in 0 until temp.size){
            res = fun1(res, temp[i])
        }

        return res
    }

    //zip: [T]->...->[T]->[[T]](упрощения: у массивов одинаковый размер, один тип элементов)
    fun <T> zip(vararg temps: ArrayList<T>): ArrayList<ArrayList<T>>{
        val arr = ArrayList<ArrayList<T>>()
        for (i in 0 until temps[0].size){
            val arri = ArrayList<T>()
            for (temp in temps){
                arri.add(temp[i])
            }
            arr.add(arri)
        }

        return arr
    }

}