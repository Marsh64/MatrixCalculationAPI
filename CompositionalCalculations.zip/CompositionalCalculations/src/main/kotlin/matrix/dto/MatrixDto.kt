package M.matrix.dto

import M.matrix.Types
import TB.matrix.TypicalBasis
import kotlinx.serialization.KSerializer
import kotlinx.serialization.Serializable
import kotlinx.serialization.descriptors.PrimitiveKind
import kotlinx.serialization.descriptors.PrimitiveSerialDescriptor
import kotlinx.serialization.descriptors.SerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import java.util.*


@Serializable
data class MatrixImplListDto<E>(
    val rows: Int,
    val columns: Int,
    @Serializable(with = TypesSerializer::class)
    val type: Types,
    val matrix: MutableList<MutableList<E>>
)

object TypesSerializer : KSerializer<Types> {
    fun fromValue(value: Int) = Types.values().find { it.num == value }!!
    override val descriptor = PrimitiveSerialDescriptor("Types", PrimitiveKind.INT)
    override fun deserialize(decoder: Decoder) = fromValue(decoder.decodeInt())
    override fun serialize(encoder: Encoder, value: Types) = encoder.encodeInt(value.num)
}

