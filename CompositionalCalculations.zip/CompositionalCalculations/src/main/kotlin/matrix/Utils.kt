package M.matrix

import kotlinx.serialization.Serializable

enum class Operation{
    None, Plus, Minus, Times, Inverse
}

enum class OperationType{
    Unary, Binary
}

enum class ElementType{
    Int, Float
}

@Serializable
enum class Types(val num: Int){
    int(0), float(1)
}