import M.dsl.BasicCombinationScheme as bcs
import org.junit.jupiter.api.Test
import kotlin.test.assertEquals

class TestBCS {

    @Test
    fun actionTest(){
        val a = 5
        val fun1 = {b:Int -> b * 5}
        val fun2 = {b: Int -> b.toString()}

        assertEquals(bcs.action(a, fun1), 25)
        assertEquals(bcs.action(a, fun2), "5")
    }

    @Test
    fun conditionTest(){
        val getBool1 = false
        val getBool2 = true
        val a = 5
        val b = 6

        assertEquals(bcs.condition(getBool1, a, b), b)
        assertEquals(bcs.condition(getBool2, a, b), a)
    }

    @Test
    fun copmositionTest(){
        val a = 1
        val b = 2
        val c = "1.0"
        val fun1 = { f: Int -> f * f }
        val fun2 = { f : Int -> f * f * f }
        val fun3 = { f: Int -> f.toFloat() }
        val fun4 = { f: Float -> f.toString() }

        assertEquals(bcs.composition(fun1, fun2)(a), 1)
        assertEquals(bcs.composition(fun1, fun2)(b), 64)
        assertEquals(bcs.composition(fun3, fun4)(a), c)
    }

    @Test
    fun merge(){
        val arr = arrayListOf(1, 2, 3)
        assertEquals(bcs.merge(1, 2, 3), arr)
    }

    @Test
     fun mapTest(){
        val arr1 = arrayListOf<Int>(1, 2, 3, 4, 5)
        val fun1 = { i:Int -> i * 2}
        val res1 = arrayListOf<Int>(2, 4, 6, 8, 10)
        val fun2 = { i:Int -> (i.toFloat() * 2).toString()}
        val res2 = arrayListOf<String>("2.0", "4.0", "6.0", "8.0", "10.0")

        assertEquals(bcs.map(arr1, fun1), res1)
        assertEquals(bcs.map(arr1, fun2), res2)
     }

    @Test
    fun flatMapTest(){
        val arr1 = arrayListOf<Int>(1, 2, 3, 4, 5)
        val fun1 = { i:Int -> arrayListOf<Int>(i, i * 2)}
        val res1 = arrayListOf<Int>(1, 2, 2, 4, 3, 6, 4, 8, 5, 10)
//        val res1 = arrayListOf<ArrayList<Int>>(arrayListOf(1, 2), arrayListOf(2, 4),
//            arrayListOf(3, 6), arrayListOf(4, 8), arrayListOf(5, 10))
//        println(res1)
        val fun2 = { i:Int -> List<String>(i-1){ _: Int -> "i"}.toMutableList() as ArrayList<String>}
        val res2 = arrayListOf<String>("i", "i", "i", "i", "i", "i", "i", "i", "i", "i")

        assertEquals(bcs.flatMap(arr1, fun1), res1)
        assertEquals(bcs.flatMap(arr1, fun2), res2)
    }

    @Test
    fun reduceTest(){
        val arr1 = arrayListOf<Int>(1, 2, 3, 4, 5)
        val fun1 = {a: Int, b: Int -> a + b}
        val res1 = 15

        assertEquals(bcs.reduce(arr1, fun1), res1)
    }

    @Test
    fun foldTest(){
        val arr1 = arrayListOf<Int>(1, 2, 3, 4, 5)
        val start = ""
        val fun1 = {a: String, b: Int -> a.toString() + b.toString()}
        val res1 = "12345"

        assertEquals(bcs.fold(arr1, start, fun1), res1)
    }

    @Test
    fun zipTest(){
        val arr1 = arrayListOf<Int>(1, 2, 3, 4, 5)
        val arr2 = arrayListOf<Int>(2, 4, 6, 8, 10)
        val res1 = arrayListOf<ArrayList<Int>>(arrayListOf(1, 2), arrayListOf(2, 4),
            arrayListOf(3, 6), arrayListOf(4, 8), arrayListOf(5, 10))

        assertEquals(bcs.zip(arr1, arr2), res1)
    }
}