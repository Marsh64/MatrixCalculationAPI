
rootProject.name = "CompositionalCalculations"

