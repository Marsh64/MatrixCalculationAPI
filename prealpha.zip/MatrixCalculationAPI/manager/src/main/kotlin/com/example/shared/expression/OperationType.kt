package shared.expression

enum class OperationType {
    NONE, unary, binary
}