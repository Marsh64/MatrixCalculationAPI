import TB.matrix.IntTypicalBasis
import kotlinx.serialization.json.Json
import matrix.MatrixImplList
import rpcServer.Worker
import shared.expression.Expression
import kotlinx.serialization.encodeToString

fun main(args: Array<String>) {
//    println("Hello World!")
//
//    val m1 = MatrixEasy(3, 5, true)
//    println(m1)
//    val m2 = MatrixEasy(3, 5, true)
//    println(m2)
//    println(m1 + m2)
//
//    val M1 = MatrixImplList.eye(2, IntTypicalBasis()).asDto()
//    val M2 = MatrixImplList.eye(2, IntTypicalBasis()).asDto()
//    val M3 =  MatrixImplList(2, 2, IntTypicalBasis(), mutableListOf<MutableList<Int>>(mutableListOf(1, 2), mutableListOf(3, 4))).asDto()
//
//    val expr1 = Expression{
//        transpose(M1 + M3 + (M2 - M1)) + M2 - inverse(transpose(M2 + inverse(M2) - M1))
//    }
//
//    val expr2 = Expression{
//        M1 + M2
//    }
//
//    val expr3 = Expression{
//        (M1 + (M2 + M3)) + M3 - (M2 + M3)
//    }
//
//
//    val exprH2 = expr3.asExpressionHolder()
//    val exH2String = Json.encodeToString(exprH2)
//    println(exH2String)
//    println(expr2.asExpressionHolder())

    val worker = Worker()
    worker.startConsuming()
}