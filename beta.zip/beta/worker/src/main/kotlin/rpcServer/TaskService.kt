package rpcServer


import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.serializer
import matrix.MatrixImplList
import matrix.asMatrix
import shared.Logger
import shared.expression.Operation
import shared.expression.TaskHolder

object TaskService {

    private val logger = Logger()

    fun calculateTask(taskMessage: String): String {
        //val gson = GsonBuilder().registerTypeAdapter(TableDto::class.java, TableDtoSerializer()).create()
        //val taskHolder = gson.fromJson(message, TaskHolder::class.java)
        val taskHolder = Json.decodeFromString<TaskHolder<Int>>(taskMessage)//TODO поправить Int


        logger.info("received task: (${taskHolder.operation.name}), ${taskHolder.arg1}, ${taskHolder.arg2}")

        val result = when (taskHolder.operation) {
            Operation.PLUS -> (taskHolder.arg1!!.asMatrix() + taskHolder.arg2!!.asMatrix()).asDto()
            Operation.MINUS -> (taskHolder.arg1!!.asMatrix() - taskHolder.arg2!!.asMatrix()).asDto()
            Operation.INVERSE -> taskHolder.arg1!!.asMatrix().inverse().asDto()
            Operation.TRANSPOSE -> taskHolder.arg1!!.asMatrix().transpose().asDto()
            //Operation.PROJECTION -> TODO()
            //Operation.SELECT -> TODO()
            //Operation.JOIN -> TODO()
            else-> throw IllegalArgumentException("TaskService.calculateTask: Invalid operation ${taskHolder.operation}")
        }
        logger.info("result matrix: $result")

        return Json.encodeToString(result)
    }
}