package com.example.route

import com.example.rpcClient.ResultsRepository
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import kotlinx.coroutines.async
import rpcClient.ExpressionService
import shared.Logger
import shared.expression.Expression
import shared.expression.ExpressionHolder
import shared.matrix.MatrixImplListDto

fun Route.expressionRouting() {

    route("/example"){
        get{
            Logger.info("Route.expressionRouting(/example): received expression via POST")
            val exampleExpressionHolderIntString = "{\"argsList\":[{\"rows\":2,\"columns\":2,\"type\":0,\"matrix\":[[1,0],[0,1]]}],\"rootExpr\":{\"operation\":\"PLUS\",\"leftTableIndex\":0,\"rightTableIndex\":0}}"
            call.respondText(exampleExpressionHolderIntString)
        }
    }

    route("/expression") {
        post {
            Logger.info("Route.expressionRouting(/expression): received expression via POST")
            val expr = call.receive<ExpressionHolder<Int>>()
            Logger.info("Route.expressionRouting(/expression): received expression successfully serialized")
            Logger.info("Route.expressionRouting(/expression): ${expr}")
            // not blocking here, only sending tasks
            val deferredResult = async {
                val ret = ExpressionService.compute(expr)
                Logger.info("Route.expressionRouting(/expression): expression via POST is sent")
                ret
            }
            val id = ResultsRepository.put(deferredResult)

            call.respond(id)
            Logger.info("Route.expressionRouting(/expression): sent response to POST")
        }

        get {
            //get result of expression using it's id
            Logger.info("Route.expressionRouting(/expression): received GET request for results")
            val corrId = call.request.queryParameters["id"]
            //проверку на ошибку надо сделать...
            val result = ResultsRepository.get(corrId!!.toInt()) // waiting for result here
            call.respond<MatrixImplListDto<Int>>(result)
            Logger.info("Route.expressionRouting(/expression): sent response to GET")
        }
    }
}