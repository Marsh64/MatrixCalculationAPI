package com.example.rpcClient

import kotlinx.coroutines.Deferred
import shared.matrix.MatrixImplListDto

object ResultsRepository {
    private val results : MutableMap<Int, Deferred<MatrixImplListDto<Int>>> = mutableMapOf()
    private var counter : Int = 0

    suspend fun get(id : Int) : MatrixImplListDto<Int>{
        if (id < 0 || id > counter - 1){
            throw IllegalArgumentException("ResultsRepository.get: id is out of result indices")
        }

        return results[id]!!.await()
    }

    fun put(future : Deferred<MatrixImplListDto<Int>>) : Int{
        val id = counter++
        results[id] = future

        return id
    }
}