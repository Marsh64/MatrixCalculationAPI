package shared.matrix

import kotlinx.serialization.KSerializer
import kotlinx.serialization.Serializable
import kotlinx.serialization.descriptors.PrimitiveKind
import kotlinx.serialization.descriptors.PrimitiveSerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder


@Serializable
data class MatrixImplListDto<E>(
    val rows: Int,
    val columns: Int,
    @Serializable(with = TypesSerializer::class)
    val type: ElementType,
    val matrix: MutableList<MutableList<E>>
)

object TypesSerializer : KSerializer<ElementType> {
    fun fromValue(value: Int) = ElementType.values().find { it.num == value }!!
    override val descriptor = PrimitiveSerialDescriptor("ElementType", PrimitiveKind.INT)
    override fun deserialize(decoder: Decoder) = fromValue(decoder.decodeInt())
    override fun serialize(encoder: Encoder, value: ElementType) = encoder.encodeInt(value.num)
}

//Example:
//val arr = mutableListOf<MutableList<Int>>(mutableListOf<Int>(1, 2), mutableListOf<Int>(3, 4))
//val m3 = MatrixImplList(2, 2, IntTypicalBasis(), arr).asDto().asMatrix().asDto()
//println(m3)
//val a = Json.encodeToString(m3)
//println(a)
//val b = Json.decodeFromString<MatrixImplListDto<Int>>(a)
//println(b)