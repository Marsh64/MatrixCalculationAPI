package shared.expression

enum class Operation {
    NONE, PLUS, MINUS, TRANSPOSE, INVERSE
}